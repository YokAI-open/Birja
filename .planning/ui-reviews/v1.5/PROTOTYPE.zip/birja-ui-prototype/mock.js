const stocks = [
  ['AAPL', 'Apple', 'NASDAQ', 27836, 1.24, 'A', '#e7e5df'],
  ['MSFT', 'Microsoft', 'NASDAQ', 50942, .72, 'M', '#e5ecdf'],
  ['NVDA', 'NVIDIA', 'NASDAQ', 18318, 2.18, 'N', '#e4ebda'],
  ['AMZN', 'Amazon', 'NASDAQ', 22481, -.38, 'a', '#f4e8d4'],
  ['GOOGL', 'Alphabet Class A', 'NASDAQ', 29122, .94, 'G', '#e3e9ee'],
  ['META', 'Meta Platforms', 'NASDAQ', 61384, -.65, 'M', '#e3e9f4'],
  ['TSLA', 'Tesla', 'NASDAQ', 41722, 1.78, 'T', '#f3e3df'],
  ['AVGO', 'Broadcom', 'NASDAQ', 34716, 1.05, 'B', '#f2e7de'],
  ['AMD', 'Advanced Micro Devices', 'NASDAQ', 22657, -.82, 'A', '#ece6e2'],
  ['COST', 'Costco', 'NASDAQ', 94123, .24, 'C', '#f2e4e1'],
  ['JPM', 'JPMorgan Chase', 'NYSE', 31352, .51, 'J', '#e6e6e2'],
  ['V', 'Visa', 'NYSE', 33056, .22, 'V', '#e4e8f3'],
  ['JNJ', 'Johnson & Johnson', 'NYSE', 20243, .15, 'J', '#f3e4e3'],
  ['PG', 'Procter & Gamble', 'NYSE', 14548, -.47, 'P', '#e5e9f1'],
  ['KO', 'Coca-Cola', 'NYSE', 6887, .12, 'K', '#f1e4df'],
  ['XOM', 'ExxonMobil', 'NYSE', 11422, -.33, 'X', '#f0e2df'],
  ['CVX', 'Chevron', 'NYSE', 15218, -.12, 'C', '#e6e9f0'],
  ['HD', 'Home Depot', 'NYSE', 35281, .53, 'H', '#f1e6df'],
  ['MCD', 'McDonald’s', 'NYSE', 30910, .29, 'M', '#f0e7da'],
  ['DIS', 'Walt Disney', 'NYSE', 10622, -.53, 'D', '#e7e9f3'],
  ['ORCL', 'Oracle', 'NYSE', 20843, .79, 'O', '#f2e6e1'],
  ['UBER', 'Uber Technologies', 'NYSE', 8935, -.28, 'U', '#e7e5df'],
  ['CRM', 'Salesforce', 'NYSE', 23527, .18, 'S', '#e4eaf3'],
  ['SBUX', 'Starbucks', 'NASDAQ', 8429, -.18, 'S', '#e1eae3'],
  ['PLTR', 'Palantir', 'NASDAQ', 15325, 1.85, 'P', '#e9e7e2'],
].map(([symbol, name, exchange, price, change, mark, color]) => ({symbol, name, exchange, price, change, mark, color, kind: 'stock'}));
const crypto = [
  ['BTC', 'Bitcoin', 9643128, 2.14, '₿', '#f3e6d3'],
  ['ETH', 'Ethereum', 341871, 1.07, 'Ξ', '#e8e5f0'],
  ['SOL', 'Solana', 14865, -1.28, 'S', '#e5ece2'],
  ['XRP', 'XRP', 218, -.27, 'X', '#e6e7e9'],
  ['ADA', 'Cardano', 71, .32, 'A', '#e4e9f3'],
].map(([symbol, name, price, change, mark, color]) => ({symbol, name, price, change, mark, color, kind: 'crypto'}));
const assets = new Map([...stocks, ...crypto].map(asset => [asset.symbol, asset]));
const initial = {
  active: 1,
  portfolios: [
    {id: 1, name: 'Long-term strategy', description: 'US stocks and a core Bitcoin position.', cash: 428640, holdings: [
      {symbol: 'AAPL', units: 12, cost: 24810},
      {symbol: 'BTC', units: 28_000_00, cost: 8540820},
      {symbol: 'MSFT', units: 2, cost: 46634},
    ], trend: [10, 9.9, 10.5, 10.2, 10.6, 10.4, 10.8, 10.5, 11.1, 10.95, 11.35]},
    {id: 2, name: 'Tech momentum', description: 'A concentrated tech strategy.', cash: 340520, holdings: [
      {symbol: 'NVDA', units: 21, cost: 19141},
      {symbol: 'TSLA', units: 6, cost: 42962},
    ], trend: [10, 9.8, 10.2, 10.1, 9.9, 9.6, 10.02, 9.9, 10.1, 9.8, 9.76]},
  ],
  events: [
    {portfolio: 1, type: 'Buy', symbol: 'AAPL', units: 4, price: 24770, cash: -99080, day: 'November 23, 2026', time: '10:42 AM'},
    {portfolio: 1, type: 'Dividend', symbol: 'MSFT', units: 2, price: 91, cash: 182, day: 'November 23, 2026', time: '9:30 AM'},
    {portfolio: 1, type: 'Buy', symbol: 'BTC', units: 28_000_00, price: 8540820, cash: -239383, fee: 239, day: 'November 19, 2026', time: '2:16 PM'},
    {portfolio: 1, type: 'Buy', symbol: 'MSFT', units: 2, price: 46634, cash: -93268, day: 'November 19, 2026', time: '10:02 AM'},
    {portfolio: 2, type: 'Buy', symbol: 'NVDA', units: 21, price: 19141, cash: -401961, day: 'November 19, 2026', time: '9:48 AM'},
    {portfolio: 1, type: 'Sell', symbol: 'AAPL', units: 3, price: 24310, cash: 72930, day: 'November 16, 2026', time: '11:05 AM'},
    {portfolio: 1, type: 'Funding', cash: 1_000_000, day: 'November 12, 2026', time: '9:00 AM'},
    {portfolio: 2, type: 'Funding', cash: 1_000_000, day: 'November 12, 2026', time: '9:00 AM'},
  ],
  scenario: 'open',
  signedIn: false,
};
const query = new URLSearchParams(location.search);
const storageKey = 'birja-ui-prototype-1';
let state = structuredClone(initial);
try { const saved = localStorage.getItem(storageKey); if (saved) state = JSON.parse(saved); } catch {}
if (['open', 'closed'].includes(query.get('session'))) state.scenario = query.get('session');
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const currency = new Intl.NumberFormat('en-US', {style: 'currency', currency: 'USD'});
const money = cents => currency.format(cents / 100);
const signedMoney = cents => (cents === 0 ? '' : cents > 0 ? '+' : '−') + money(Math.abs(cents));
const percent = n => (n === 0 ? '' : n > 0 ? '+' : '−') + Math.abs(n).toFixed(2) + '%';
const tone = n => n > 0 ? 'gain' : n < 0 ? 'loss' : 'muted';
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
const multiplier = asset => asset.kind === 'crypto' ? 100_000_000 : 1;
const amount = (units, asset) => (units / multiplier(asset)).toLocaleString('en-US', {maximumFractionDigits: 8});
const gross = (units, cents, asset) => {
  const scale = BigInt(multiplier(asset));
  return Number((BigInt(units) * BigInt(cents) + scale / 2n) / scale);
};
function save() { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch {} }
function selected() {
  const id = Number(query.get('portfolio')) || state.active;
  return state.portfolios.find(portfolio => portfolio.id === id) || state.portfolios[0];
}
function tradeLink(asset, portfolio = selected()) {
  const params = new URLSearchParams({symbol: asset.symbol, session: state.scenario});
  if (portfolio) params.set('portfolio', portfolio.id);
  return 'trade.html?' + params;
}
function picker(onChange) {
  const control = $('.portfolio-picker');
  if (!control) return;
  if (!state.portfolios.length) {
    control.replaceChildren(new Option('No portfolios', ''));
    control.disabled = true;
    return;
  }
  control.replaceChildren(...state.portfolios.map(p => new Option(p.name, p.id)));
  control.value = selected().id;
  control.onchange = () => {
    state.active = Number(control.value);
    query.set('portfolio', control.value);
    window.history.replaceState(null, '', '?' + query);
    save();
    onChange?.();
  };
}
function venue(asset) { return asset.kind === 'crypto' ? 'Crypto' : asset.exchange; }
function stamp(asset) {
  return `<span class="asset-stamp" aria-hidden="true" style="--stamp:${asset.color}">${asset.mark}</span>`;
}
const mockSessionLength = (2 * 60 + 30) * 60_000;
let demoOpening = new Date(state.opensAt || Date.now() + mockSessionLength);
function marketClosed(asset) { return asset.kind === 'stock' && state.scenario === 'closed'; }
function status(asset) {
  if (marketClosed(asset)) {
    const minutes = Math.max(0, Math.ceil((demoOpening - Date.now()) / 60_000));
    const localTime = demoOpening.toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'});
    return `<p class="market-state warn" title="Opens at ${escape(localTime)} local time"><strong>Market closed</strong><span>Opens in ${Math.floor(minutes / 60)} hr ${minutes % 60} min</span></p>`;
  }
  return `<p class="market-state gain"><strong>${asset.kind === 'stock' ? 'Market open' : 'Trading open'}</strong></p>`;
}
function stats(portfolio) {
  const value = {cash: portfolio.cash, stock: 0, crypto: 0};
  for (const holding of portfolio.holdings) {
    const asset = assets.get(holding.symbol);
    value[asset.kind] += gross(holding.units, asset.price, asset);
  }
  const total = value.cash + value.stock + value.crypto;
  return {value, total, delta: total - 1_000_000, rate: (total - 1_000_000) / 10_000};
}
function trace(canvas, values, options = {}) {
  const {width, height} = canvas.getBoundingClientRect();
  if (!width || !height) return;
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  const ctx = canvas.getContext('2d');
  ctx.scale(ratio, ratio);
  const {axis = false, labels = [], color = '#326349'} = options;
  const x0 = axis ? 1 : 2, x1 = width - (axis ? 67 : 2), y0 = axis ? 10 : 5, y1 = height - (axis ? 29 : 4);
  const rawMin = Math.min(...values), rawMax = Math.max(...values);
  const padding = Math.max((rawMax - rawMin) * .16, rawMax * .0003, .0001);
  const min = rawMin - padding, max = rawMax + padding;
  const x = i => x0 + (x1 - x0) * i / (values.length - 1);
  const y = v => y1 - (v - min) / (max - min) * (y1 - y0);
  if (axis) {
    ctx.font = '11px Inter, system-ui';
    ctx.strokeStyle = '#e5e0d6';
    ctx.fillStyle = '#625e53';
    for (let i = 0; i <= 4; i++) {
      const level = y0 + (y1 - y0) * i / 4;
      ctx.beginPath();
      ctx.moveTo(x0, level);
      ctx.lineTo(x1, level);
      ctx.stroke();
      ctx.textAlign = 'right';
      const dollars = (max - (max - min) * i / 4) / 100;
      ctx.fillText(dollars >= 1000 ? '$' + dollars.toLocaleString('en-US', {maximumFractionDigits: 0}) : '$' + dollars.toFixed(dollars < 5 ? 2 : 0), width - 1, level + 4);
    }
    labels.forEach((label, i) => {
      ctx.textAlign = i === 0 ? 'left' : i === labels.length - 1 ? 'right' : 'center';
      ctx.fillText(label, x0 + (x1 - x0) * i / (labels.length - 1), height - 7);
    });
  }
  ctx.beginPath();
  values.forEach((value, i) => i === 0 ? ctx.moveTo(x(i), y(value)) : ctx.lineTo(x(i), y(value)));
  if (axis) {
    const line = new Path2D();
    values.forEach((value, i) => i === 0 ? line.moveTo(x(i), y(value)) : line.lineTo(x(i), y(value)));
    ctx.lineTo(x1, y1);
    ctx.lineTo(x0, y1);
    ctx.closePath();
    const fill = ctx.createLinearGradient(0, y0, 0, y1);
    fill.addColorStop(0, color + '27');
    fill.addColorStop(1, color + '04');
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.beginPath();
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = color;
    ctx.lineJoin = 'round';
    ctx.stroke(line);
    ctx.beginPath();
    ctx.arc(x1, y(values.at(-1)), 4, 0, 2 * Math.PI);
    ctx.fillStyle = color;
    ctx.fill();
  } else {
    ctx.lineWidth = 1.65;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = color;
    ctx.stroke();
  }
}
function marketPage() {
  let kind = 'stock', asset = stocks[0], period = '1W';
  const search = $('#search');
  const scenario = $('#market-scenario');
  const chart = $('#market-chart');
  scenario.value = state.scenario;
  function draw() {
    const patterns = {
      '1D': [-.3,-.5,-.2,-.45,-.1,.13,-.03,.44,.3,.53,.38,.71,.51,.82,1],
      '1W': [.05,.23,.14,.35,.22,.48,.38,.51,.34,.56,.76,.64,.73,.57,.88,.81,.99,.9,1],
      '1M': [.1,.21,.08,.34,.21,.32,.49,.41,.67,.53,.57,.67,.62,.83,.78,.95,.83,1],
    };
    const captions = {'1D': ['Today', ['9:30', '11:00', '12:30', '2:00']], '1W': ['Past week', ['Mon','Tue','Wed','Thu','Fri']], '1M': ['Past month', ['Week 1','Week 2','Week 3','Week 4']]};
    const rate = period === '1D' ? asset.change : Math.sign(asset.change) * (period === '1W' ? 2.9 : 7.4);
    const start = asset.price / (1 + rate / 100);
    const points = patterns[period].map(v => start + (asset.price - start) * v);
    $('#chart-caption').innerHTML = `${captions[period][0]} <strong class="${tone(rate)}">${percent(rate)}</strong>`;
    chart.setAttribute('aria-label', asset.symbol + ' mock price chart, ' + captions[period][0].toLowerCase() + ', ending at ' + money(asset.price));
    trace(chart, points, {axis: true, labels: captions[period][1], color: rate > 0 ? '#326349' : '#a03429'});
  }
  function detail() {
    $('#asset-quote').innerHTML = `<div class="quote-top"><div class="quote-title">${stamp(asset)}<div><h2 tabindex="-1">${asset.name}</h2><p class="asset-meta">${asset.symbol} · ${venue(asset)}</p></div></div>${status(asset)}</div><div class="quote-price"><strong class="price">${money(asset.price)}</strong><span class="${tone(asset.change)}">${percent(asset.change)} today</span></div>`;
    const p = selected();
    const held = p?.holdings.find(item => item.symbol === asset.symbol);
    const note = held ? `${amount(held.units, asset)} ${asset.kind === 'stock' ? (held.units === 1 ? 'share' : 'shares') : asset.symbol} held` : p ? `${money(p.cash)} cash` : '';
    $('#market-action').innerHTML = `<span class="muted">${note}</span><a class="button ${marketClosed(asset) ? '' : 'primary'}" href="${p ? tradeLink(asset) : 'portfolios.html'}">${p ? (marketClosed(asset) ? 'View ticket' : 'Trade ' + asset.symbol) : 'New portfolio'}</a>`;
    draw();
  }
  function rows() {
    const text = search.value.trim().toLowerCase();
    const results = (kind === 'stock' ? (text ? stocks : stocks.slice(0, 20)) : crypto)
      .filter(item => item.symbol.toLowerCase().includes(text) || item.name.toLowerCase().includes(text));
    if (results.length && !results.includes(asset)) asset = results[0];
    $('#asset-list').innerHTML = results.length
      ? results.map(item => `<button class="asset-row" type="button" data-symbol="${item.symbol}" aria-pressed="${item === asset}"><span class="asset-id">${stamp(item)}<span class="asset-text"><b>${item.symbol}</b><small>${item.name}</small></span></span><span>${money(item.price)}</span><span class="${tone(item.change)}">${percent(item.change)}</span></button>`).join('')
      : '<p class="empty">No matches. Try a different name or ticker.</p>';
    $('#listing-count').textContent = results.length ? (text ? `${results.length} ${results.length === 1 ? 'result' : 'results'}` : kind === 'stock' ? '20 featured stocks' : '5 cryptocurrencies') : '';
    detail();
  }
  $('#asset-list').onclick = event => {
    const row = event.target.closest('[data-symbol]');
    if (!row) return;
    asset = assets.get(row.dataset.symbol);
    $$('.asset-row').forEach(button => button.setAttribute('aria-pressed', String(button === row)));
    detail();
    if (matchMedia('(max-width: 740px)').matches) $('.quote-title h2').focus({preventScroll: false});
  };
  $$('.market-tabs button').forEach(button => button.onclick = () => {
    kind = button.dataset.kind;
    $$('.market-tabs button').forEach(tab => tab.setAttribute('aria-pressed', String(tab === button)));
    search.value = '';
    search.setAttribute('aria-label', kind === 'stock' ? 'Search stocks' : 'Search crypto');
    rows();
  });
  $$('#ranges button').forEach(button => button.onclick = () => {
    period = button.textContent;
    $$('#ranges button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    draw();
  });
  search.oninput = rows;
  scenario.onchange = () => {
    state.scenario = scenario.value;
    state.opensAt = state.scenario === 'closed' ? Date.now() + mockSessionLength : null;
    demoOpening = new Date(state.opensAt || Date.now() + mockSessionLength);
    save();
    detail();
  };
  picker(detail);
  new ResizeObserver(draw).observe(chart);
  if (document.fonts) document.fonts.ready.then(draw);
  setInterval(() => {
    if (marketClosed(asset)) $('.quote-top .market-state').outerHTML = status(asset);
  }, 20_000);
  rows();
}
function portfolioForm(portfolio) {
  const dialog = $('#portfolio-dialog');
  const form = $('#portfolio-form');
  const error = $('#form-error');
  const name = form.elements.name;
  const description = form.elements.description;
  error.hidden = true;
  name.value = portfolio?.name || '';
  description.value = portfolio?.description || '';
  form.onsubmit = event => {
    event.preventDefault();
    const text = name.value.trim();
    const notes = description.value.trim();
    if (!text || state.portfolios.some(p => p.id !== portfolio?.id && p.name.toLowerCase() === text.toLowerCase())) {
      error.textContent = text ? 'This portfolio name is already in use.' : 'Enter a portfolio name.';
      error.hidden = false;
      name.focus();
      return;
    }
    if (portfolio) {
      portfolio.name = text;
      portfolio.description = notes;
      save();
      dialog.close();
      picker(portfolioDetail);
      portfolioDetail();
    } else {
      if (state.portfolios.length >= 10) return;
      const id = Date.now();
      state.portfolios.push({id, name: text, description: notes, cash: 1_000_000, holdings: [], trend: [10, 10]});
      state.active = id;
      state.events.unshift({portfolio: id, type: 'Funding', cash: 1_000_000, ...now()});
      save();
      location.href = 'portfolio.html?portfolio=' + id;
    }
  };
  dialog.showModal();
  name.focus();
}
function portfoliosPage() {
  $('#portfolio-cards').innerHTML = state.portfolios.map(p => {
    const {total, rate} = stats(p);
    return `<a class="panel portfolio-card" href="portfolio.html?portfolio=${p.id}"><div class="card-title"><h2>${escape(p.name)}</h2><span aria-hidden="true">↗</span></div>${p.description ? `<p class="card-description">${escape(p.description)}</p>` : ''}<canvas class="card-chart" data-portfolio="${p.id}" aria-hidden="true"></canvas><div class="card-value"><strong>${money(total)}</strong><span class="${tone(rate)}">${percent(rate)}</span></div><div class="card-cash">${money(p.cash)} cash</div></a>`;
  }).join('') + `<button class="panel portfolio-card new-card" id="new-portfolio" ${state.portfolios.length >= 10 ? 'disabled' : ''}><span aria-hidden="true">+</span><h2>New portfolio</h2></button>`
    + (state.portfolios.length >= 10 ? '<p class="muted">You’ve reached the limit of 10 active portfolios.</p>' : '');
  $('#new-portfolio').onclick = () => portfolioForm();
  const observer = new ResizeObserver(entries => entries.forEach(({target}) => {
    const portfolio = state.portfolios.find(p => p.id === Number(target.dataset.portfolio));
    const {total, rate} = stats(portfolio);
    trace(target, [...portfolio.trend.slice(0, -1), total / 100_000], {color: rate < 0 ? '#a03429' : '#326349'});
  }));
  $$('.card-chart').forEach(canvas => observer.observe(canvas));
}
function portfolioDetail() {
  const p = selected();
  if (!p) {
    $('#portfolio-workspace').innerHTML = '<p class="empty">You don’t have a portfolio yet. <a href="portfolios.html">Create a portfolio</a></p>';
    return;
  }
  const {value, total, delta, rate} = stats(p);
  const types = [['cash', 'Cash'], ['stock', 'Stocks'], ['crypto', 'Crypto']];
  const weight = key => total > 0 ? value[key] / total * 100 : 0;
  $('#portfolio-summary').innerHTML = `<div class="summary-value"><p class="muted">Total value</p><strong class="price">${money(total)}</strong><p class="${tone(delta)}">${signedMoney(delta)} (${percent(rate)}) <span class="muted">all time</span></p></div><div><div class="allocation-strip" aria-hidden="true">${types.filter(([key]) => weight(key)).map(([key]) => `<span class="alloc-${key}" style="flex:${weight(key)}"></span>`).join('')}</div><dl class="allocation-key">${types.map(([key, label]) => `<div><dt><i class="alloc-${key}" aria-hidden="true"></i>${label}</dt><dd><strong>${weight(key).toFixed(1)}%</strong><span>${money(value[key])}</span></dd></div>`).join('')}</dl></div>`;
  const filter = $('#holding-filter').value;
  const sort = $('#holding-sort').value;
  const rows = p.holdings.map(h => {
    const asset = assets.get(h.symbol);
    const marketValue = gross(h.units, asset.price, asset);
    const basis = gross(h.units, h.cost, asset);
    return {h, asset, marketValue, rate: basis ? (marketValue - basis) / basis * 100 : 0};
  }).filter(({asset}) => filter === 'all' || asset.kind === filter);
  rows.sort((a, b) => sort === 'ticker' ? a.asset.symbol.localeCompare(b.asset.symbol) : sort === 'return' ? b.rate - a.rate : b.marketValue - a.marketValue);
  $('#holdings-list').innerHTML = rows.map(({h, asset, marketValue, rate}) => `<a class="panel holding" href="${tradeLink(asset, p)}"><div class="holding-heading">${stamp(asset)}<div><h3>${asset.symbol}</h3><p class="asset-meta">${asset.name} · ${asset.kind === 'stock' ? 'Stock' : 'Crypto'}</p></div></div><div class="holding-value"><strong>${money(marketValue)}</strong><span class="${tone(rate)}">${percent(rate)}</span></div><div class="holding-meta"><span>${amount(h.units, asset)} ${asset.kind === 'stock' ? (h.units === 1 ? 'share' : 'shares') : asset.symbol}</span><span>Avg. cost ${money(h.cost)}</span></div></a>`).join('') || '<p class="empty">No holdings to show.</p>';
}
function portfolioPage() {
  if (!selected()) { portfolioDetail(); return; }
  picker(portfolioDetail);
  portfolioDetail();
  $('#holding-filter').onchange = portfolioDetail;
  $('#holding-sort').onchange = portfolioDetail;
  $('#edit-portfolio').onclick = () => portfolioForm(selected());
  let refresh = Date.now() - 12_000;
  function tick() { $('#update-age').textContent = Math.floor((Date.now() - refresh) / 1000) + 's ago'; }
  $('#update-portfolio').onclick = () => { refresh = Date.now(); tick(); portfolioDetail(); };
  setInterval(tick, 1000);
  $('#remove-portfolio').onclick = () => {
    $('#remove-message').textContent = 'Remove “' + selected().name + '” from your active portfolios? Its cash and positions stay with it.';
    $('#remove-dialog').showModal();
  };
  $('#remove-form').onsubmit = event => {
    event.preventDefault();
    const removed = selected();
    state.portfolios = state.portfolios.filter(p => p.id !== removed.id);
    state.active = state.portfolios[0]?.id;
    save();
    location.href = 'portfolios.html';
  };
}
function now() {
  const date = new Date();
  return {day: date.toLocaleDateString('en-US', {dateStyle: 'long'}), time: date.toLocaleTimeString('en-US', {timeStyle: 'short'})};
}
function historyPage() {
  function render() {
    const p = selected();
    const type = $('#history-type').value;
    const kind = $('#history-asset').value;
    const items = state.events.filter(event => event.portfolio === p?.id && (type === 'all' || event.type === type) && (kind === 'all' || assets.get(event.symbol)?.kind === kind));
    let day = '';
    $('#history-list').innerHTML = items.map(event => {
      const asset = assets.get(event.symbol);
      const heading = event.day === day ? '' : `<h2 class="history-day">${escape(event.day)}</h2>`;
      day = event.day;
      const icon = asset ? stamp(asset) : '<span class="asset-stamp" aria-hidden="true">$</span>';
      const details = asset
        ? [[event.type === 'Dividend' ? 'Shares on record' : 'Quantity', amount(event.units, asset) + (asset.kind === 'crypto' ? ' ' + asset.symbol : '')], [event.type === 'Dividend' ? 'Cash per share' : 'Fill price', money(event.price)], ...(event.fee ? [['Fee', money(event.fee)]] : [])]
        : [['Source', 'Starting virtual cash']];
      details.push(['Cash change', signedMoney(event.cash)]);
      return `${heading}<details class="event"><summary><span class="event-title">${icon}<span><strong>${event.type}${asset ? ' · ' + asset.symbol : ''}</strong><small>${asset ? asset.name + ' · ' : ''}${escape(event.time)}</small></span></span><span class="${tone(event.cash)}">${signedMoney(event.cash)}</span></summary><dl class="event-details">${details.map(([label, value]) => `<div><dt>${label}</dt><dd>${value}</dd></div>`).join('')}</dl></details>`;
    }).join('') || '<p class="empty">No activity to show.</p>';
  }
  picker(render);
  $('#history-type').onchange = render;
  $('#history-asset').onchange = render;
  render();
}
function tradePage() {
  const asset = assets.get(query.get('symbol')) || stocks[0];
  const market = $('#trade-market');
  const preview = $('#order-preview');
  const quantity = $('#quantity');
  const shortcut = $('#quantity-shortcut');
  const error = $('#order-error');
  const previewButton = $('#preview-button');
  const scale = multiplier(asset);
  const stock = asset.kind === 'stock';
  let side = 'buy';
  const formatSide = () => side === 'buy' ? 'Buy' : 'Sell';
  const ask = stock ? asset.price + 4 : Math.round(asset.price * 1.0025);
  const bid = stock ? asset.price - 4 : Math.round(asset.price * .9975);
  const price = () => side === 'buy' ? ask : bid;
  const holding = () => selected()?.holdings.find(h => h.symbol === asset.symbol);
  const costs = units => {
    const subtotal = gross(units, price(), asset);
    const fee = stock ? 0 : Math.max(1, Math.round(subtotal * .0025));
    return {subtotal, fee, cash: side === 'buy' ? subtotal + fee : subtotal - fee};
  };
  function maxBuy() {
    const cash = selected()?.cash || 0;
    let low = 0, high = Math.floor(cash / price() * scale) + 1;
    while (low < high) {
      const mid = Math.ceil((low + high) / 2);
      if (costs(mid).cash <= cash) low = mid;
      else high = mid - 1;
    }
    return low;
  }
  function resetPreview() {
    error.hidden = true;
    preview.innerHTML = marketClosed(asset)
      ? '<h2>Trade preview</h2><p class="muted">Trading resumes when the market opens.</p>'
      : '<h2>Trade preview</h2><p class="muted">Enter a quantity to preview your trade.</p>';
  }
  function ticket() {
    const p = selected();
    const closed = marketClosed(asset);
    market.innerHTML = `<div class="trade-market"><strong class="trade-price">${money(asset.price)}</strong>${status(asset)}</div>` + (closed ? '' : `<dl class="book"><div class="${side === 'sell' ? 'execution-price' : ''}"><dt>${stock ? 'Bid' : 'Sell price'}</dt><dd>${money(bid)}</dd></div><div class="${side === 'buy' ? 'execution-price' : ''}"><dt>${stock ? 'Ask' : 'Buy price'}</dt><dd>${money(ask)}</dd></div></dl>`);
    $('#trade-cash').textContent = money(p?.cash || 0);
    $('#trade-owned').textContent = `${amount(holding()?.units || 0, asset)} ${stock ? 'shares' : asset.symbol} held`;
    shortcut.textContent = side === 'buy' ? 'Buy max' : 'Sell all';
    shortcut.hidden = closed || !p;
    previewButton.textContent = 'Preview ' + side;
    previewButton.hidden = closed || !p;
    if (!p) preview.innerHTML = '<h2>Trade preview</h2><p><a href="portfolios.html">Create a portfolio</a> to start trading.</p>';
  }
  $('#trade-heading').innerHTML = `${stamp(asset)}<div><h1>Trade ${asset.symbol}</h1><p class="asset-meta">${asset.name} · ${venue(asset)}</p></div>`;
  $('#quantity-unit').textContent = stock ? 'shares' : asset.symbol;
  quantity.step = stock ? '1' : '0.00000001';
  quantity.min = quantity.step;
  quantity.inputMode = stock ? 'numeric' : 'decimal';
  $$('.trade-side button').forEach(button => button.onclick = () => {
    side = button.dataset.side;
    $$('.trade-side button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    resetPreview();
    ticket();
  });
  quantity.oninput = resetPreview;
  shortcut.onclick = () => {
    quantity.value = ((side === 'buy' ? maxBuy() : holding()?.units || 0) / scale).toFixed(stock ? 0 : 8).replace(stock ? /$/ : /\.?0+$/, '');
    resetPreview();
  };
  $('#order-form').onsubmit = event => {
    event.preventDefault();
    if (marketClosed(asset) || !selected()) return;
    const p = selected();
    const units = Math.round(Number(quantity.value) * scale);
    if (!Number.isSafeInteger(units) || units <= 0) return;
    const {subtotal, fee, cash} = costs(units);
    const purchase = side === 'buy';
    const position = holding();
    const invalid = subtotal < 1 ? 'Trade value must be at least $0.01.' : purchase && cash > p.cash ? 'This order exceeds your available cash.' : !purchase && units > (position?.units || 0) ? 'This order exceeds your holdings.' : '';
    if (invalid) { error.textContent = invalid; error.hidden = false; return; }
    const after = p.cash + (purchase ? -cash : cash);
    const lines = [['Quantity', amount(units, asset) + (stock ? ' shares' : ' ' + asset.symbol)], ['Price', money(price())], ['Order value', money(subtotal)], ['Fee', money(fee)], ['Cash after trade', money(after)]];
    const details = `<dl class="breakdown">${lines.map(([label, value], i) => `<div class="${i === lines.length - 1 ? 'total' : ''}"><dt>${label}</dt><dd>${value}</dd></div>`).join('')}</dl>`;
    preview.innerHTML = `<h2>${formatSide()} ${asset.symbol}</h2>${details}<button class="button primary" id="confirm-order">Confirm ${side}</button>`;
    $('#confirm-order').focus({preventScroll: false});
    $('#confirm-order').onclick = () => {
      const fillPrice = price();
      if (purchase) {
        const updatedUnits = (position?.units || 0) + units;
        const oldBasis = position ? gross(position.units, position.cost, asset) : 0;
        const cost = Math.round((oldBasis + cash) * scale / updatedUnits);
        if (position) Object.assign(position, {units: updatedUnits, cost});
        else p.holdings.push({symbol: asset.symbol, units, cost});
      } else {
        position.units -= units;
        if (!position.units) p.holdings = p.holdings.filter(item => item !== position);
      }
      p.cash = after;
      state.events.unshift({portfolio: p.id, type: formatSide(), symbol: asset.symbol, units, price: fillPrice, fee, cash: purchase ? -cash : cash, ...now()});
      save();
      quantity.value = '';
      ticket();
      preview.innerHTML = `<h2 tabindex="-1">Order filled</h2><p class="gain">${formatSide()} · ${asset.symbol}</p>${details}<div class="receipt-actions"><a class="button" href="portfolio.html?portfolio=${p.id}">Portfolio</a><a class="button" href="history.html?portfolio=${p.id}">History</a></div>`;
      $('h2', preview).focus({preventScroll: true});
    };
  };
  picker(() => { resetPreview(); ticket(); });
  resetPreview();
  ticket();
  if (marketClosed(asset)) setInterval(() => { $('.market-state', market).outerHTML = status(asset); }, 20_000);
}
function authPage() {
  const email = $('#email-form');
  const code = $('#code-form');
  function authState() {
    email.hidden = state.signedIn;
    code.hidden = true;
    $('#signed-in').hidden = !state.signedIn;
    $('#auth-title').textContent = state.signedIn ? 'Signed in' : 'Sign in';
  }
  authState();
  email.onsubmit = event => {
    event.preventDefault();
    email.hidden = true;
    code.hidden = false;
    code.elements.code.focus();
  };
  $('#different-email').onclick = () => { authState(); email.elements.email.focus(); };
  code.onsubmit = event => {
    event.preventDefault();
    const isValid = code.elements.code.value === '123456';
    $('#code-error').hidden = isValid;
    if (!isValid) { code.elements.code.focus(); return; }
    state.signedIn = true;
    save();
    location.href = 'index.html';
  };
  $('#sign-out').onclick = () => { state.signedIn = false; save(); authState(); };
}
$$('[data-close]').forEach(button => button.onclick = () => button.closest('dialog').close());
if (state.signedIn) {
  const account = $('.account');
  account.setAttribute('aria-label', 'Sign out');
  account.title = 'Sign out';
  account.onclick = event => {
    event.preventDefault();
    state.signedIn = false;
    save();
    location.href = 'sign-in.html';
  };
}
const pages = {index: marketPage, portfolios: portfoliosPage, portfolio: portfolioPage, history: historyPage, trade: tradePage, 'sign-in': authPage};
pages[document.body.dataset.page]?.();
